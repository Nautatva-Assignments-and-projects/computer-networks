#include "node.h"
#include <iostream>

using namespace std;

void routingAlgo(vector<RoutingNode*> nd){
  //Your code here
}


void RoutingNode::recvMsg(RouteMsg *msg) {
  //your code here
}




